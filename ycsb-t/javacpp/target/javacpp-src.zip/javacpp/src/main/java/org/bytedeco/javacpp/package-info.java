/**
 * Contains the main set of classes for JavaCPP at runtime.
 */
package org.bytedeco.javacpp;
